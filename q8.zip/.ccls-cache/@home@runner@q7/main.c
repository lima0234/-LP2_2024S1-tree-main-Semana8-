#include <stdio.h>

int divisiveis_soma(int arr[], int tam, int x) {
    if (tam == 0) {
        return 0;
    }
    return (arr[tam - 1] % x == 0 ? arr[tam - 1] : 0) + divisiveis_soma(arr, tam - 1, x);
}

int main() {
    int arr[] = {10, 20, 30, 40, 50};
    int tam = sizeof(arr) / sizeof(arr[0]);
    int x = 10;

    printf("Soma dos elementos do array divisíveis por %d: %d\n", x, divisiveis_soma(arr, tam, x));

    return 0;
}
