#include <stdio.h>

int divisiveis_quantidade(int arr[], int tam, int x) {
    if (tam == 0) {
        return 0;
    }

    return (arr[tam - 1] % x == 0) + divisiveis_quantidade(arr, tam - 1, x);
}

int main() {
    int arr[] = {10, 20, 30, 40, 50};
    int tam = sizeof(arr) / sizeof(arr[0]);
    int x = 10;

    printf("Quantidade de elementos do array divisíveis por %d: %d\n", x, divisiveis_quantidade(arr, tam, x));

    return 0;
}
